# Flower Detection > 2023-08-18 6:22pm
https://universe.roboflow.com/dissertation-qmii2/flower-detection-cvybj

Provided by a Roboflow user
License: CC BY 4.0

